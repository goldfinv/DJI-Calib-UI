﻿# Phantom 3 Pro/Adv model

## Author

Based on the work of @jianghanmao
https://grabcad.com/library/dji-phantom3-1

Motors based on work of @Nonthanut.Hoku
https://grabcad.com/library/dji-phantom-brushless-dc-1

## License

The author agreeds to use of the model within free, open-source software,
as long as he is properly credited. Please contact the author if you wish
to use this model under different conditions.
