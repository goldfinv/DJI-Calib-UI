disable_lua = false

dofile('dji-dumlv1-proto.lua')

dofile('dji-p3-flyrec-proto.lua')
dofile('dji-p3-batt-proto.lua')
dofile('dji-p3.lua')

dofile('dji-mavic-flyrec-proto.lua')
dofile('dji-mavic.lua')

dofile('dji-spark-flyrec-proto.lua')
dofile('dji-spark.lua')

dofile('dji-write-kml.lua')
